import pyautogui
import tkinter as tk
from pynput.mouse import Listener

def update_cursor_label():
    x, y = pyautogui.position()
    cursor_label.config(text=f"X: {x}, Y: {y}")
    root.after(50, update_cursor_label) 

def on_move(x, y):
    print('Mouse moved to ({0}, {1})'.format(x, y))

def on_click(x, y, button, pressed):
    if pressed:
        print('Mouse clicked at ({0}, {1}) with {2}'.format(x, y, button))
    else:
        print('Mouse released at ({0}, {1}) with {2}'.format(x, y, button))

def on_scroll(x, y, dx, dy):
    print('Mouse scrolled at ({0}, {1})({2}, {3})'.format(x, y, dx, dy))

root = tk.Tk()
root.title("Mouse Tracking System")
root.geometry("300x50")

cursor_label = tk.Label(root, text="", font=("Helvetica", 16))
cursor_label.pack()

update_cursor_label()

with Listener(on_move=on_move, on_click=on_click, on_scroll=on_scroll) as listener:
    root.mainloop()
    listener.join()
