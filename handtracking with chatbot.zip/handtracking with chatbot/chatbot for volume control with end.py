import cv2
import mediapipe as mp
from math import hypot
from ctypes import cast, POINTER
from comtypes import CLSCTX_ALL
from pycaw.pycaw import AudioUtilities, IAudioEndpointVolume
import numpy as np

def detect_hand_gesture_increase():
    cap = cv2.VideoCapture(0)
    mpHands = mp.solutions.hands
    hands = mpHands.Hands()
    mpDraw = mp.solutions.drawing_utils

    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    volume = cast(interface, POINTER(IAudioEndpointVolume))
    volMin, volMax = volume.GetVolumeRange()[:2]

    x1, y1, x2, y2 = 0, 0, 0, 0
    initial_volume = volume.GetMasterVolumeLevel()
    prev_vol = initial_volume  # To track previous volume

    while True:
        success, img = cap.read()
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = hands.process(imgRGB)
        lmList = []

        if results.multi_hand_landmarks:
            for handlandmark in results.multi_hand_landmarks:
                for id, lm in enumerate(handlandmark.landmark):
                    h, w, c = img.shape
                    cx, cy = int(lm.x * w), int(lm.y * h)
                    lmList.append([id, cx, cy])
                mpDraw.draw_landmarks(img, handlandmark, mpHands.HAND_CONNECTIONS)

            if lmList != []:
                x1, y1 = lmList[4][1], lmList[4][2]
                x2, y2 = lmList[8][1], lmList[8][2]

        length = hypot(x2 - x1, y2 - y1)
        vol = np.interp(length, [15, 220], [volMin, volMax])
        volume.SetMasterVolumeLevel(vol, None)

        final_volume = volume.GetMasterVolumeLevel()
        if vol == volMax and final_volume != prev_vol:
            percentage_change = (final_volume - initial_volume) / (volMax - initial_volume) * 100
            change = percentage_change
            print(f"Volume increased by {change:.2f}%. Current Volume: {final_volume:.2f}")
            prev_vol = final_volume  # Update the previous volume

        cv2.imshow('Image', img)

        if cv2.waitKey(1) & 0xFF == ord('q') or vol == volMax:
            break

    cap.release()
    cv2.destroyAllWindows()

def detect_hand_gesture_decrease():
    cap = cv2.VideoCapture(0)
    mpHands = mp.solutions.hands
    hands = mpHands.Hands()
    mpDraw = mp.solutions.drawing_utils

    devices = AudioUtilities.GetSpeakers()
    interface = devices.Activate(IAudioEndpointVolume._iid_, CLSCTX_ALL, None)
    volume = cast(interface, POINTER(IAudioEndpointVolume))
    volMin, volMax = volume.GetVolumeRange()[:2]

    x1, y1, x2, y2 = 0, 0, 0, 0
    initial_volume = volume.GetMasterVolumeLevel()
    prev_vol = initial_volume  # To track previous volume

    while True:
        success, img = cap.read()
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        results = hands.process(imgRGB)
        lmList = []

        if results.multi_hand_landmarks:
            for handlandmark in results.multi_hand_landmarks:
                for id, lm in enumerate(handlandmark.landmark):
                    h, w, c = img.shape
                    cx, cy = int(lm.x * w), int(lm.y * h)
                    lmList.append([id, cx, cy])
                mpDraw.draw_landmarks(img, handlandmark, mpHands.HAND_CONNECTIONS)

            if lmList != []:
                x1, y1 = lmList[4][1], lmList[4][2]
                x2, y2 = lmList[8][1], lmList[8][2]

        length = hypot(x2 - x1, y2 - y1)
        vol = np.interp(length, [15, 220], [volMin, volMax])
        volume.SetMasterVolumeLevel(vol, None)

        final_volume = volume.GetMasterVolumeLevel()
        if vol == volMin and final_volume != prev_vol:
            percentage_change = (initial_volume - final_volume) / (initial_volume - volMin) * 100
            change = percentage_change
            print(f"Volume decreased by {change:.2f}%. Current Volume: {final_volume:.2f}")
            prev_vol = final_volume  # Update the previous volume

        cv2.imshow('Image', img)

        if cv2.waitKey(1) & 0xFF == ord('q') or vol == volMin:
            break

    cap.release()
    cv2.destroyAllWindows()

print("Chatbot: Hi! I can help you control the volume.")
while True:
    user_input = input("Chatbot: Do you want to increase or decrease the volume? (Type 'exit' to quit): ")
    if user_input.lower() == 'increase':
        detect_hand_gesture_increase()
    elif user_input.lower() == 'decrease':
        detect_hand_gesture_decrease()
    elif user_input.lower() == 'exit':
        print("Chatbot: Goodbye!")
        break
    else:
        print("Chatbot: Sorry, I didn't understand. Please type 'increase', 'decrease', or 'exit'.")
